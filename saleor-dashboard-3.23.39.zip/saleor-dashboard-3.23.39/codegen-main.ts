import { type CodegenConfig } from "@graphql-codegen/cli";

const config: CodegenConfig = {
  // schema-directives declares @lockSchema, which the API does not know about
  schema: ["./schema-main.graphql", "./schema-directives.graphql"],
  documents: [
    "./src/**/queries.ts",
    "./src/**/mutations.ts",
    "./src/**/fragments/*.ts",
    "./src/searches/*.ts",
    // covered by codegen-staging
    "!./src/**/queries.staging.ts",
    "!./src/**/mutations.staging.ts",
    "!./src/**/fragments/*.staging.ts",
    "!./src/searches/*.staging.ts",
  ],
  generates: {
    "./src/graphql/fragmentTypes.generated.ts": {
      plugins: ["fragment-matcher"],
      config: {
        minify: false,
        apolloClientVersion: 3,
      },
    },
    "./src/graphql/typePolicies.generated.ts": {
      plugins: ["typescript-apollo-client-helpers"],
    },
    "./src/graphql/types.generated.ts": {
      plugins: ["typescript", "typescript-operations"],
      config: {
        scalars: {
          Day: "number",
          Hour: "number",
          Date: "string",
          // TODO Enable and fix types one by one
          // _Any: "unknown",
          // DateTime: "string",
          // Decimal: "number",
          // Minute: "number",
          // GenericScalar: "JSONValue",
          JSON: "unknown",
          JSONString: "string",
          // Metadata: "Record<string, string>",
          // PositiveDecimal: "number",
          // Upload: "unknown",
          // UUID: "string",
          // WeightScalar: "number",
        },
        nonOptionalTypename: true,
        avoidOptionals: {
          field: true,
          inputValue: false,
          object: false,
          defaultValue: false,
        },
        namingConvention: {
          enumValues: "change-case-all#upperCase",
        },
        onlyOperationTypes: true,
      },
    },
    "./src/graphql/hooks.generated.ts": {
      plugins: ["typescript-react-apollo"],
      config: {
        withHooks: true,
        apolloReactHooksImportFrom: "@dashboard/hooks/graphql",
      },
      preset: "import-types",
      presetConfig: {
        typesPath: "./types.generated",
      },
    },
    "./src/graphql/fabbricaTypes.generated.ts": {
      plugins: ["typescript"],
      config: {
        enumsAsTypes: true,
        avoidOptionals: true,
        nonOptionalTypename: true,
        scalars: {
          Day: "number",
          Hour: "number",
          Date: "string",
        },
        namingConvention: {
          enumValues: "change-case-all#upperCase",
        },
      },
    },
    "./src/graphql/fabbrica.generated.ts": {
      plugins: ["@mizdra/graphql-codegen-typescript-fabbrica"],
      config: {
        typesFile: "./fabbricaTypes.generated",
      },
    },
  },
};

export default config;
