import { URL_LIST } from "@data/url";
import type { Page } from "@playwright/test";

import { BasePage } from "./basePage";

export class ConfigurationPage extends BasePage {
  constructor(
    page: Page,
    readonly pluginsButton = page.locator("[data-test-id*='plugins']"),
    readonly installedExtensionsButton = page.locator("[data-test-id*='installed-extensions']"),
    readonly permissionGroupsButton = page.locator("[data-test-id*='permission-groups']"),
    readonly staffMembersButton = page.locator("[data-test-id*='staff members']"),
    readonly siteSettingsButton = page.locator("[data-test-id*='site-settings']"),
    readonly channelsButton = page.locator("[data-test-id*='channels']"),
    readonly shippingMethodsButton = page.locator("[data-test-id*='shipping methods']"),
    readonly productTypesButton = page.locator("[data-test-id*='product-types']"),
    readonly webhooksAndEventsButton = page.locator("[data-test-id*='webhooks']"),
    readonly productAttributesButton = page.locator(
      "[data-test-id^='configuration-menu-product-attributes-']",
    ),
    readonly modelAttributesButton = page.locator(
      "[data-test-id^='configuration-menu-model-attributes-']",
    ),
    readonly pageTypesButton = page.locator("[data-test-id*='configuration-menu-page-type']"),
    readonly taxesButton = page.locator("[data-test-id*='configuration-menu-taxes']"),
  ) {
    super(page);
  }

  async openShippingMethods() {
    await this.shippingMethodsButton.click();
  }

  async openTaxes() {
    await this.taxesButton.click();
  }

  async openChannels() {
    await this.channelsButton.click();
  }

  async openPermissionGroups() {
    await this.permissionGroupsButton.click();
  }

  async openStaffMembers() {
    await this.staffMembersButton.click();
  }

  async openSiteSettings() {
    await this.siteSettingsButton.click();
  }

  async openProductTypes() {
    await this.productTypesButton.click();
  }

  async openPageTypes() {
    await this.pageTypesButton.click();
  }

  async openPlugins() {
    await this.pluginsButton.click();
  }

  async openInstalledExtensions() {
    await this.installedExtensionsButton.click();
  }

  async goToConfigurationView() {
    await this.page.goto(URL_LIST.configuration);
  }

  async openWebhooksAndEvents() {
    await this.webhooksAndEventsButton.click();
  }

  async openAttributes(attributeClass: "PRODUCT_TYPE" | "PAGE_TYPE") {
    const attributesButton =
      attributeClass === "PRODUCT_TYPE" ? this.productAttributesButton : this.modelAttributesButton;

    await attributesButton.click();
  }
}
