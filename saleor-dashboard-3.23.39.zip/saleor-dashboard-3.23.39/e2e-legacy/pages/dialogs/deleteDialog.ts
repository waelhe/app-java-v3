import { BasePage } from "@pages/basePage";
import type { Page } from "@playwright/test";

export class DeleteDialog extends BasePage {
  constructor(
    page: Page,
    readonly deleteButton = page.getByTestId("submit"),
    readonly confirmDeletionCheckbox = page.getByTestId("delete-assigned-items-consent"),
    readonly confirmDeleteButton = page.getByTestId("confirm-delete"),
  ) {
    super(page);
  }

  async clickDeleteButton() {
    await this.deleteButton.first().click();
    await this.deleteButton.waitFor({ state: "hidden" });
  }

  async clickConfirmDeletionCheckbox() {
    await this.confirmDeletionCheckbox.click();
  }

  async clickConfirmDeleteButton() {
    await this.confirmDeleteButton.click();
    await this.confirmDeleteButton.waitFor({ state: "hidden" });
  }
}
