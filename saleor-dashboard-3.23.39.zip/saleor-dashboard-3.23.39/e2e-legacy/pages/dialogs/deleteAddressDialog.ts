import { BasePage } from "@pages/basePage";
import { type Page } from "@playwright/test";

export class DeleteAddressDialog extends BasePage {
  constructor(
    page: Page,

    readonly backButton = page.getByTestId("back"),
    readonly submitButton = page.getByTestId("submit"),
  ) {
    super(page);
  }

  async clickBackButton() {
    await this.backButton.click();
  }

  async clickDeleteButton() {
    await this.waitForNetworkIdleAfterAction(async () => {
      await this.submitButton.click();
    });
  }
}
