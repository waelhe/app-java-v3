import { CHANNELS } from "@data/e2eTestData";
import { URL_LIST } from "@data/url";
import { AddCountriesDialog } from "@dialogs/addCountriesDialog";
import { MetadataSeoPage } from "@pageElements/metadataSeoPage";
import { BasePage } from "@pages/basePage";
import { expect, type Page } from "@playwright/test";

export class TaxesPage extends BasePage {
  readonly page: Page;

  readonly addCountriesDialog: AddCountriesDialog;

  readonly metadataSeoPage: MetadataSeoPage;

  constructor(
    page: Page,
    readonly appOrFlatRateSelect = page.getByTestId("tax-calculation-strategy-select"),
    readonly channelListRow = page.getByTestId("channels-list-rows"),
    readonly countriesListRow = page.getByTestId("countries-list-rows"),
    readonly classListRow = page.getByTestId("class-list-rows"),
    readonly countriesTab = page.getByTestId("countries-tab"),
    readonly taxClassTab = page.getByTestId("tax-classes-tab"),
    readonly enteredRenderedSection = page.getByTestId("entered-rendered-prices-section"),
    readonly pricesEnteredWithTaxButton = page.locator(
      "[name='pricesEnteredWithTax'][ value='true']",
    ),
    readonly pricesEnteredWithoutTaxButton = page.locator(
      "[name='pricesEnteredWithTax'][ value='false']",
    ),
    readonly displayGrossPricesCheckbox = page.locator("[name='displayGrossPrices']"),
    readonly addCountryButton = page.getByTestId("add-country-button"),
    readonly createClassButton = page.getByTestId("create-class-button"),
    readonly saveButton = page.getByTestId("button-bar-confirm"),
    readonly exceptionCountryRows = page.getByTestId("exception-country"),
    readonly exceptionCountryGrossPriceCheckbox = page.getByTestId("display-gross-prices-checkbox"),
    readonly checkBoxCheckedState = page.locator("Mui-checked"),
    readonly exceptionCountriesCheckBoxCheckedState = page.locator("[class*='Mui-checked']"),
    readonly searchTaxClassInput = page.getByTestId("search-tax-class-input").locator("input"),
    readonly searchedCountryRows = page.getByTestId("country-rows"),

    readonly searchTaxCountryInput = page.getByRole("textbox", { name: "Search tax countries" }),
    readonly taxClassNameInput = page.getByTestId("class-name-input"),
    readonly noTaxRateInput = page.getByTestId("No Taxes").locator("input"),
    readonly defaultRateInput = page.getByTestId("Country default rate").locator("input"),
    readonly audioProductsRateInput = page
      .getByTestId("Audio Products (tapes, cds etc.)")
      .locator("input"),
    readonly dataServicesRateInput = page
      .getByTestId("Data services - storage and retrieval ")
      .locator("input"),
    readonly standardRateInput = page.getByTestId("standard").locator("input"),
    readonly temporaryUnmappedRateInput = page
      .getByTestId("Temporary Unmapped Other SKU - taxable default")
      .locator("input"),
  ) {
    super(page);
    this.page = page;
    this.addCountriesDialog = new AddCountriesDialog(page);
    this.metadataSeoPage = new MetadataSeoPage(page);
  }

  async clickSelectMethodField() {
    await this.appOrFlatRateSelect.click();
  }

  async typeAllTaxRatesForCountry(
    defaultRate: string,
    noTaxRate: string,
    audioRate: string,
    dataServiceRate: string,
    standardRate: string,
    temporaryRate: string,
  ) {
    await this.defaultRateInput.fill(defaultRate);
    await this.audioProductsRateInput.fill(audioRate);
    await this.dataServicesRateInput.fill(dataServiceRate);
    await this.noTaxRateInput.fill(noTaxRate);
    await this.standardRateInput.fill(standardRate);
    await this.temporaryUnmappedRateInput.fill(temporaryRate);
  }

  async clickCountriesTab() {
    await this.countriesTab.click();
    await this.countriesListRow.first().waitFor({ state: "visible" });
  }

  async clickTaxClassTab() {
    await this.taxClassTab.click();
    await this.classListRow.first().waitFor({ state: "visible" });
  }

  async clickCountryFromList(countryCode: string) {
    await this.countriesListRow.filter({ hasText: countryCode }).click();
  }

  async clickSaveButton() {
    await this.saveButton.click();
  }

  async typeTaxClassName(taxClassName: string) {
    await this.taxClassNameInput.fill(taxClassName);
  }

  async typeSearchedTaxCountryName(taxCountryName: string) {
    await this.searchTaxCountryInput.fill(taxCountryName);
    // Verify the input value is set before checking filtered results
    await expect(this.searchTaxCountryInput).toHaveValue(taxCountryName);
    // Wait for search results to filter
    await this.searchedCountryRows
      .filter({ hasText: taxCountryName })
      .waitFor({ state: "visible", timeout: 10000 });
  }

  async typeTaxRateInSearchedCountryRow(taxCountryName: string, taxRateValue: string) {
    const countryRow = this.searchedCountryRows.filter({ hasText: taxCountryName });

    await countryRow.waitFor({ state: "visible", timeout: 10000 });

    const input = countryRow.locator("input");

    await input.waitFor({ state: "visible", timeout: 5000 });
    await input.fill(taxRateValue);
  }

  async clickCreateClassButton() {
    await this.createClassButton.click();
    // Wait for the new tax class form to load
    await this.taxClassNameInput.waitFor({ state: "visible" });
  }

  async selectTaxCalculationMethod(method: string) {
    await this.clickSelectMethodField();
    await this.page.getByTestId("select-option").filter({ hasText: method }).first().click();
  }

  async selectPricesWithoutTaxes() {
    await this.enteredRenderedSection.locator(this.pricesEnteredWithoutTaxButton).click();
  }

  async selectPricesWithTaxes() {
    await this.enteredRenderedSection.locator(this.pricesEnteredWithTaxButton).click();
  }

  async clickShowGrossPricesInStorefront() {
    await this.enteredRenderedSection.locator(this.displayGrossPricesCheckbox).click();
  }

  async clickAddCountryButton() {
    await this.addCountryButton.click();
  }

  async selectChannel(channelName: string) {
    await this.channelListRow.filter({ hasText: channelName }).click();
  }

  async gotoChannelsTabUrl() {
    await this.page.goto(URL_LIST.taxChannel + CHANNELS.plnChannel.id);
  }
}
