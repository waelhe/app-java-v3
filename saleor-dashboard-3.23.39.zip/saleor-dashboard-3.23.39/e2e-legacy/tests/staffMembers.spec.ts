import { USERS } from "@data/e2eTestData";
import { ConfigurationPage } from "@pages/configurationPage";
import { StaffMembersPage } from "@pages/staffMembersPage";
import { expect } from "@playwright/test";
import { test } from "utils/testWithPermission";

test.use({ permissionName: "admin" });

let staffMembersPage: StaffMembersPage;
let config: ConfigurationPage;

interface StaffMember {
  id?: string;
  name: string;
  lastName: string;
  email: string;
}

test.beforeEach(async ({ page, request }) => {
  staffMembersPage = new StaffMembersPage(page, request);
  config = new ConfigurationPage(page);

  await config.goToConfigurationView();
  await config.openStaffMembers();
});

test("TC: SALEOR_211 Create a staff member #e2e #staff-members", async () => {
  const staffMember: StaffMember = {
    name: "John",
    lastName: "Create",
    email: `test.staff.john.create@example.com`,
  };

  await expect(async () => {
    await staffMembersPage.clickInviteStaffMemberButton();
  }).toPass();
  await staffMembersPage.inviteStaffMembersDialog.typeNameLastNameAndEmail(
    staffMember.name,
    staffMember.lastName,
    staffMember.email,
  );
  await staffMembersPage.inviteStaffMembersDialog.sendInviteButton.waitFor({ state: "visible" });
  await staffMembersPage.inviteStaffMembersDialog.clickSendInviteButton();
  await staffMembersPage.expectSuccessBanner();

  await expect(staffMembersPage.firstName).toHaveValue(staffMember.name);
  await expect(staffMembersPage.lastName).toHaveValue(staffMember.lastName);
  await expect(staffMembersPage.email).toHaveValue(staffMember.email);
  await expect(staffMembersPage.staffStatusButton).toHaveText("Deactivate");
  await expect(staffMembersPage.staffMemberStatus).toContainText("Pending invite");

  await staffMembersPage.clickPermissionsGroupSelectButton();

  await staffMembersPage.assignUserToPermissionGroup("Customer Support");
  await staffMembersPage.assignUserToPermissionGroup("Channels Management");

  await staffMembersPage.clickSaveButton();

  await staffMembersPage.verifyAssignedPermission("Customer Support");
  await staffMembersPage.verifyAssignedPermission("Channels Management");
});
test("TC: SALEOR_212 Edit a staff member #e2e #staff-members", async () => {
  const updatedStaffMember: StaffMember = {
    name: "John",
    lastName: "Edit",
    email: `test.staff.john.edit@example.com`,
  };

  await staffMembersPage.gotToExistingStaffMemberPage(USERS.staffToBeEdited.id);
  await staffMembersPage.updateStaffInfo(
    updatedStaffMember.name,
    updatedStaffMember.lastName,
    updatedStaffMember.email,
  );

  await staffMembersPage.clickPermissionsGroupSelectButton();
  await staffMembersPage.assignUserToPermissionGroup("Customer Support");
  await staffMembersPage.assignUserToPermissionGroup("Channels Management");

  await staffMembersPage.clickSaveButton();
  await staffMembersPage.expectSuccessBanner();

  await expect(staffMembersPage.firstName).toHaveValue(updatedStaffMember.name);
  await expect(staffMembersPage.lastName).toHaveValue(updatedStaffMember.lastName);
  await expect(staffMembersPage.email).toHaveValue(updatedStaffMember.email);

  await staffMembersPage.clickPermissionsGroupSelectButton();

  await staffMembersPage.verifyAssignedPermission("Customer Support");
  await staffMembersPage.verifyAssignedPermission("Channels Management");
  await staffMembersPage.verifyAssignedPermission(USERS.staffToBeEdited.permission);
});
test("TC: SALEOR_213 Delete a single staff member #e2e #staff-members", async () => {
  await staffMembersPage.gotToExistingStaffMemberPage(USERS.staffToBeDeleted.id);
  await staffMembersPage.clickDeleteButton();
  await staffMembersPage.clickSubmitButton();
  await staffMembersPage.expectSuccessBanner();
  await staffMembersPage.typeInSearchOnListView(USERS.staffToBeDeleted.name);
  await expect(staffMembersPage.emptyDataGridListView).toBeVisible();
});
