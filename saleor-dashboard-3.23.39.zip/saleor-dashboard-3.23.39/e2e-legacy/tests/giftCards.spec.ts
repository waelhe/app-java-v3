import { GIFT_CARDS } from "@data/e2eTestData";
import { GiftCardsPage } from "@pages/giftCardsPage";
import { expect } from "@playwright/test";
import { test } from "utils/testWithPermission";

test.use({ permissionName: "admin" });

let giftCardsPage: GiftCardsPage;

test.beforeEach(async ({ page }) => {
  test.slow();
  giftCardsPage = new GiftCardsPage(page);
  await giftCardsPage.gotoGiftCardsListView();
  await giftCardsPage.waitForDOMToFullyLoad();
});
test("TC: SALEOR_105 Issue gift card #e2e #gift", async () => {
  await giftCardsPage.clickIssueCardButton();
  await expect(giftCardsPage.issueGiftCardDialog.amountDropdown).toBeVisible();
  await giftCardsPage.issueGiftCardDialog.typeAmount("50");
  await giftCardsPage.issueGiftCardDialog.typeCustomTag("super ultra automation discount");
  await giftCardsPage.issueGiftCardDialog.tagsInputBlur();
  await giftCardsPage.issueGiftCardDialog.clickRequiresActivationCheckbox();
  await giftCardsPage.issueGiftCardDialog.clickIssueButton();
  await expect(giftCardsPage.issueGiftCardDialog.cardCode).toBeVisible();
  await giftCardsPage.expectSuccessBanner({ message: "Gift card created" });

  const code = (await giftCardsPage.issueGiftCardDialog.cardCode.innerText()).slice(-4);

  await giftCardsPage.issueGiftCardDialog.clickCopyCodeButton();
  await giftCardsPage.expectSuccessBanner({ message: "Copied to clipboard" });
  await giftCardsPage.issueGiftCardDialog.clickOkButton();
  await giftCardsPage.giftCardDialog.waitFor({ state: "hidden" });
  await giftCardsPage.gotoGiftCardsListView();
  await giftCardsPage.gridCanvas
    .getByText(`Code ending with ${code}`)
    .waitFor({ state: "attached", timeout: 30000 });
});
test("TC: SALEOR_106 Issue gift card with specific customer and expiry date #e2e #gift", async () => {
  await giftCardsPage.clickIssueCardButton();

  await giftCardsPage.issueGiftCardDialog.clickSendExpireDateCheckbox();
  await giftCardsPage.issueGiftCardDialog.typeExpiryPeriodAmount("2");
  await giftCardsPage.issueGiftCardDialog.clickSendToCustomerCheckbox();
  await giftCardsPage.issueGiftCardDialog.selectCustomer("e2e-customer to-be-activated");
  await giftCardsPage.issueGiftCardDialog.clickIssueButton();
  await giftCardsPage.expectSuccessBanner({ message: "Gift card created" });
  await expect(giftCardsPage.issueGiftCardDialog.cardCode).toBeVisible();

  const fullCode = await giftCardsPage.issueGiftCardDialog.cardCode.innerText();

  await giftCardsPage.issueGiftCardDialog.clickOkButton();
  await giftCardsPage.giftCardDialog.waitFor({ state: "hidden" });
  await giftCardsPage.gotoGiftCardsListView();
  await giftCardsPage.clickFilterButton();
  await giftCardsPage.filtersPage.pickTextFilter("Code", fullCode);
  await giftCardsPage.filtersPage.clickSaveFiltersButton();

  const last4 = fullCode.slice(-4);

  await giftCardsPage.waitForCanvasContainsText(`Code ending with ${last4}`);
  expect(
    await giftCardsPage.getNumberOfGridRowsWithText(`Code ending with ${last4}`),
    "There should be only one gift card visible on list",
  ).toEqual(1);
});
test("TC: SALEOR_107 Resend code #e2e #gift", async () => {
  await giftCardsPage.clickListRowBasedOnContainingText(GIFT_CARDS.giftCardToResendCode.name);
  await giftCardsPage.clickResendCodeButton();
  // This is a workaround for the issue with the dropdown focusing on dialog open
  // Dropdown can cover the resend button and cause test to fail
  await giftCardsPage.resendGiftCardCodeDialog.blur();
  await giftCardsPage.resendGiftCardCodeDialog.clickResendButton();
  await giftCardsPage.expectSuccessBanner();
});
test("TC: SALEOR_108 Deactivate gift card #e2e #gift", async () => {
  await giftCardsPage.gotoExistingGiftCardView(GIFT_CARDS.giftCardToBeDeactivated.id);
  await giftCardsPage.clickDeactivateButton();
  await giftCardsPage.expectSuccessBanner();
  await expect(giftCardsPage.pageHeader).toContainText("Disabled");
});
test("TC: SALEOR_109 Activate gift card #e2e #gift", async () => {
  await giftCardsPage.gotoExistingGiftCardView(GIFT_CARDS.giftCardToBeActivated.id);
  await giftCardsPage.clickDeactivateButton();
  await giftCardsPage.expectSuccessBanner();
  await expect(giftCardsPage.pageHeader).not.toContainText("Disabled");
});
test("TC: SALEOR_110 Edit gift card #e2e #gift", async () => {
  await giftCardsPage.gotoExistingGiftCardView(GIFT_CARDS.giftCardToBeEdited.id);
  await giftCardsPage.openTagInput();
  await giftCardsPage.selectFirstTag();
  await giftCardsPage.selectFirstTag();
  await giftCardsPage.closeTagInput();
  await giftCardsPage.clickCardExpiresCheckbox();
  await giftCardsPage.metadataSeoPage.expandAndAddAllMetadata();
  await giftCardsPage.clickSaveButton();
  await giftCardsPage.expectSuccessBanner();
});
test("TC: SALEOR_111 Bulk delete gift cards #e2e #gift", async () => {
  await giftCardsPage.checkListRowsBasedOnContainingText(GIFT_CARDS.giftCardsToBeDeleted.names);
  await giftCardsPage.clickBulkDeleteButton();
  await giftCardsPage.deleteDialog.clickConfirmDeletionCheckbox();
  await giftCardsPage.deleteDialog.clickDeleteButton();
  await giftCardsPage.dialog.waitFor({ state: "hidden" });
  await giftCardsPage.gotoGiftCardsListView();
  for (const last4Code of GIFT_CARDS.giftCardsToBeDeleted.last4) {
    await expect(giftCardsPage.gridCanvas).not.toContainText(`Code ending with ${last4Code}`);
  }
});
test("TC: SALEOR_181 Set gift card balance #e2e #gift", async () => {
  await giftCardsPage.gotoExistingGiftCardView(GIFT_CARDS.giftCardToBeEdited.id);
  await giftCardsPage.clickSetBalance();
  await giftCardsPage.setGiftCardsBalanceDialog.setBalance("34");
  await giftCardsPage.expectSuccessBanner();
});
