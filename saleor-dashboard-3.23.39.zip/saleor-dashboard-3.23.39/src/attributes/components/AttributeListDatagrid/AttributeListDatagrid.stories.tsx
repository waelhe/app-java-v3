import { attributes } from "@dashboard/attributes/fixtures";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";

import { STORYBOOK_CHROMATIC_PARAMS } from "../../../storybook/chromatic";
import { AttributeListDatagrid } from "./AttributeListDatagrid";

const meta: Meta<typeof AttributeListDatagrid> = {
  title: "Attributes/AttributeListDatagrid",
  component: AttributeListDatagrid,

  args: {
    attributes,
    disabled: false,
    sort: { sort: "name" as any, asc: true },
    onSort: fn(),
    settings: {
      columns: ["name", "slug", "input-type", "visible", "use-in-faceted-search"],
      rowsPerPage: 20,
    },
    onUpdateListSettings: fn(),
    onSelectAttributesIds: fn(),
  },
  parameters: {
    chromatic: STORYBOOK_CHROMATIC_PARAMS.datagrid,
  },
};

export default meta;
type Story = StoryObj<typeof AttributeListDatagrid>;

export const Default: Story = {};

export const Disabled: Story = {
  args: { disabled: true },
};

export const Empty: Story = {
  args: { attributes: [] },
};
