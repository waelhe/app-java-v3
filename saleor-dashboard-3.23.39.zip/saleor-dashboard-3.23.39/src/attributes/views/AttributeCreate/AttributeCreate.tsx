import { BulkDeleteButton } from "@dashboard/components/BulkDeleteButton/BulkDeleteButton";
import {
  type AttributeCreateInput,
  AttributeErrorCode,
  type AttributeErrorFragment,
  useAttributeCreateMutation,
  useUpdateMetadataMutation,
  useUpdatePrivateMetadataMutation,
} from "@dashboard/graphql";
import useBulkActions from "@dashboard/hooks/useBulkActions";
import useListSettings from "@dashboard/hooks/useListSettings";
import useLocalPageInfo, { getMaxPage } from "@dashboard/hooks/useLocalPageInfo";
import useNavigator from "@dashboard/hooks/useNavigator";
import { useNotifier } from "@dashboard/hooks/useNotifier/useNotifier";
import { buttonMessages } from "@dashboard/intl";
import { getMutationErrors, getStringOrPlaceholder } from "@dashboard/misc";
import { ListViews, type ReorderEvent } from "@dashboard/types";
import createDialogActionHandlers from "@dashboard/utils/handlers/dialogActionHandlers";
import createMetadataCreateHandler from "@dashboard/utils/handlers/metadataCreateHandler";
import { add, isSelected, move, remove, updateAtIndex } from "@dashboard/utils/lists/lists";
import { useEffect, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import slugify from "slugify";

import AttributePage, {
  type AttributePageFormData,
} from "../../components/AttributePage/AttributePage";
import { AttributeValueDeleteDialog } from "../../components/AttributeValueDeleteDialog/AttributeValueDeleteDialog";
import { AttributeValueEditDialog } from "../../components/AttributeValueEditDialog/AttributeValueEditDialog";
import {
  attributeAddUrl,
  type AttributeAddUrlDialog,
  type AttributeAddUrlQueryParams,
  attributeUrl,
  parseAttributeTypeFromQueryParam,
} from "../../urls";
import { type AttributeValueEditDialogFormData, getAttributeData } from "../../utils/data";

type ParamId = number | undefined;

interface AttributeDetailsProps {
  params: AttributeAddUrlQueryParams;
}

const attributeValueAlreadyExistsError: AttributeErrorFragment = {
  __typename: "AttributeError",
  code: AttributeErrorCode.ALREADY_EXISTS,
  field: "name",
  message: "",
};

function areValuesEqual(a: AttributeValueEditDialogFormData, b: AttributeValueEditDialogFormData) {
  return a.name === b.name;
}

const AttributeDetails = ({ params }: AttributeDetailsProps) => {
  const navigate = useNavigator();
  const notify = useNotifier();
  const intl = useIntl();
  const [values, setValues] = useState<AttributeValueEditDialogFormData[]>([]);
  const [valueErrors, setValueErrors] = useState<AttributeErrorFragment[]>([]);
  const valueListActions = useBulkActions();
  const { updateListSettings, settings } = useListSettings(ListViews.ATTRIBUTE_VALUE_LIST);
  const { pageInfo, pageValues, loadNextPage, loadPreviousPage, loadPage } = useLocalPageInfo(
    values,
    settings?.rowNumber,
  );
  const [attributeCreate, attributeCreateOpts] = useAttributeCreateMutation({
    onCompleted: data => {
      if (data?.attributeCreate?.errors.length === 0) {
        notify({
          status: "success",
          text: intl.formatMessage({
            id: "c0hLoI",
            defaultMessage: "Attribute created",
          }),
        });
        navigate(attributeUrl(data?.attributeCreate?.attribute?.id ?? ""));
      }
    },
  });
  const [updateMetadata] = useUpdateMetadataMutation({});
  const [updatePrivateMetadata] = useUpdatePrivateMetadataMutation({});
  const id: ParamId = params.id ? parseInt(params.id, 10) : undefined;
  const [openModal, closeModal] = createDialogActionHandlers<
    AttributeAddUrlDialog,
    AttributeAddUrlQueryParams
  >(navigate, attributeAddUrl, params);

  useEffect(() => setValueErrors([]), [params.action]);

  const handleValueDelete = () => {
    if (id !== undefined) {
      const newValues = remove(values[id], values, areValuesEqual);

      setValues(newValues);
    }

    valueListActions.reset();
    closeModal();
  };
  const handleValuesDelete = () => {
    const indexes = new Set((params.ids ?? []).map(valueId => parseInt(valueId, 10)));

    setValues(values.filter((_, index) => !indexes.has(index)));
    valueListActions.reset();
    closeModal();
  };
  const handleValueUpdate = (input: AttributeValueEditDialogFormData) => {
    if (isSelected(input, values, areValuesEqual)) {
      setValueErrors([attributeValueAlreadyExistsError]);
    } else {
      if (id !== undefined) {
        setValues(updateAtIndex(input, values, id));
      }

      closeModal();
    }
  };
  const handleValueCreateMany = (inputs: AttributeValueEditDialogFormData[]) => {
    let next = values;
    let addedCount = 0;
    let hadDuplicate = false;

    inputs.forEach(input => {
      const name = input.name.trim();

      if (!name) {
        return;
      }

      const item: AttributeValueEditDialogFormData = { ...input, name };

      if (isSelected(item, next, areValuesEqual)) {
        hadDuplicate = true;

        return;
      }

      next = add(item, next);
      addedCount += 1;
    });

    if (addedCount === 0) {
      if (hadDuplicate) {
        setValueErrors([attributeValueAlreadyExistsError]);
      }

      return;
    }

    setValues(next);
    setValueErrors([]);

    const addedToNotVisibleLastPage = next.length - pageInfo.startCursor > settings.rowNumber;

    if (addedToNotVisibleLastPage) {
      const maxPage = getMaxPage(next.length, settings.rowNumber);

      loadPage(maxPage);
    }

    closeModal();
  };
  const handleValueCreate = (input: AttributeValueEditDialogFormData) => {
    handleValueCreateMany([input]);
  };
  const handleValueReorder = ({ newIndex, oldIndex }: ReorderEvent) =>
    setValues(
      move(
        values[pageInfo.startCursor + oldIndex],
        values,
        areValuesEqual,
        pageInfo.startCursor + newIndex,
      ),
    );
  const handleCreate = async (data: AttributePageFormData) => {
    const result = await attributeCreate({
      variables: {
        input: getAttributeData(data, values) as AttributeCreateInput,
      },
    });

    return {
      id: result.data?.attributeCreate?.attribute?.id ?? undefined,
      errors: getMutationErrors(result),
    };
  };
  const handleSubmit = createMetadataCreateHandler(
    handleCreate,
    updateMetadata,
    updatePrivateMetadata,
  );

  const defaultAttributeType = parseAttributeTypeFromQueryParam(params.type);

  return (
    <AttributePage
      attribute={null}
      defaultAttributeType={defaultAttributeType}
      disabled={attributeCreateOpts.loading}
      errors={attributeCreateOpts?.data?.attributeCreate?.errors || []}
      onDelete={() => undefined}
      onSubmit={handleSubmit}
      onValueAdd={() => openModal("add-value")}
      onValueDelete={id =>
        openModal("remove-value", {
          id,
        })
      }
      onValueReorder={handleValueReorder}
      onValueUpdate={id =>
        openModal("edit-value", {
          id,
        })
      }
      valueList={{
        isChecked: valueListActions.isSelected,
        selected: valueListActions.listElements.length,
        toggle: valueListActions.toggle,
        toggleAll: valueListActions.toggleAll,
        toolbar: (
          <BulkDeleteButton
            count={valueListActions.listElements.length}
            size="small"
            onClick={() => openModal("remove-values", { ids: valueListActions.listElements })}
          >
            <FormattedMessage {...buttonMessages.delete} />
          </BulkDeleteButton>
        ),
      }}
      saveButtonBarState={attributeCreateOpts.status}
      values={{
        __typename: "AttributeValueCountableConnection" as const,
        pageInfo: {
          __typename: "PageInfo" as const,
          endCursor: "",
          hasNextPage: false,
          hasPreviousPage: false,
          startCursor: "",
        },
        edges: pageValues.map((value, valueIndex) => ({
          __typename: "AttributeValueCountableEdge" as const,
          cursor: "1",
          node: {
            __typename: "AttributeValue" as const,
            file: value?.fileUrl
              ? {
                  url: value.fileUrl,
                  contentType: value.contentType ?? "",
                  __typename: "File",
                }
              : null,
            id: (pageInfo.startCursor + valueIndex).toString(),
            reference: null,
            slug: slugify(value.name).toLowerCase(),
            sortOrder: valueIndex,
            value: value.value ?? null,
            plainText: null,
            richText: null,
            boolean: null,
            date: null,
            dateTime: null,
            ...value,
          },
        })),
      }}
      settings={settings}
      onUpdateListSettings={updateListSettings}
      pageInfo={pageInfo}
      onNextPage={loadNextPage}
      onPreviousPage={loadPreviousPage}
    >
      {data => (
        <>
          <AttributeValueEditDialog
            attributeValue={null}
            confirmButtonState="default"
            disabled={false}
            errors={valueErrors}
            open={params.action === "add-value"}
            onClose={closeModal}
            onSubmit={handleValueCreate}
            onSubmitMany={handleValueCreateMany}
            inputType={data.inputType}
          />
          {values.length > 0 && (
            <>
              <AttributeValueDeleteDialog
                attributeName=""
                open={params.action === "remove-value"}
                name={getStringOrPlaceholder(id !== undefined ? values[id]?.name : "")}
                confirmButtonState="default"
                onClose={closeModal}
                onConfirm={handleValueDelete}
              />
              <AttributeValueDeleteDialog
                attributeName=""
                open={params.action === "remove-values"}
                name=""
                quantity={params.ids?.length ?? 0}
                confirmButtonState="default"
                onClose={closeModal}
                onConfirm={handleValuesDelete}
              />
              <AttributeValueEditDialog
                inputType={data.inputType}
                attributeValue={id !== undefined ? values[id] : null}
                confirmButtonState="default"
                disabled={false}
                errors={valueErrors}
                open={params.action === "edit-value"}
                onClose={closeModal}
                onSubmit={handleValueUpdate}
              />
            </>
          )}
        </>
      )}
    </AttributePage>
  );
};

AttributeDetails.displayName = "AttributeDetails";

export default AttributeDetails;
