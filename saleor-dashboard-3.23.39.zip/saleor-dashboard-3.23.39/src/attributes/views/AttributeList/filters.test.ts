import { createFilterStructure } from "@dashboard/attributes/components/AttributeListPage/filters";
import { type AttributeListUrlFilters } from "@dashboard/attributes/urls";
import { getFilterQueryParams } from "@dashboard/utils/filters/filters";
import { stringifyQs } from "@dashboard/utils/urls";
import { getExistingKeys, setFilterOptsStatus } from "@test/filters";
import { testIntlInstance } from "@test/intl";

import { getFilterQueryParam, getFilterVariables } from "./filters";

describe("Filtering query params", () => {
  it("should be empty object if no params given", () => {
    const params: AttributeListUrlFilters = {};
    const filterVariables = getFilterVariables(params);

    expect(getExistingKeys(filterVariables)).toHaveLength(0);
  });
  it("should not be empty object if params given", () => {
    const params: AttributeListUrlFilters = {
      isVariantOnly: true.toString(),
    };
    const filterVariables = getFilterVariables(params);

    expect(getExistingKeys(filterVariables)).toHaveLength(1);
  });
});
describe("Filtering URL params", () => {
  const intl = testIntlInstance;
  const filters = createFilterStructure(intl, {
    filterableInStorefront: {
      active: false,
      value: true,
    },
    isVariantOnly: {
      active: false,
      value: true,
    },
    valueRequired: {
      active: false,
      value: true,
    },
    visibleInStorefront: {
      active: false,
      value: true,
    },
  });

  it("should be empty if no active filters", () => {
    const filterQueryParams = getFilterQueryParams(filters, getFilterQueryParam);

    expect(getExistingKeys(filterQueryParams)).toHaveLength(0);
  });
  it("should not be empty if active filters are present", () => {
    const filterQueryParams = getFilterQueryParams(
      setFilterOptsStatus(filters, true),
      getFilterQueryParam,
    );

    expect(filterQueryParams).toMatchSnapshot();
    expect(stringifyQs(filterQueryParams)).toMatchSnapshot();
  });
});
