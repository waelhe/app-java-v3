import { getAppMountUriForRedirect } from "@dashboard/utils/urls";
import { useEffect } from "react";
import { useLocation } from "react-router";
import urlJoin from "url-join";

import { loginCallbackPath } from "../urls";
import { useUser } from "../useUser";
import { useAuthParameters } from "./useAuthParameters";

const PLUGIN_ID_PARAM = "saleorPluginId";

export const useAuthRedirection = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const shouldRedirect = params.has(PLUGIN_ID_PARAM);
  const { authenticated, authenticating, requestLoginByExternalPlugin, isCredentialsLogin } =
    useUser();
  const { setRequestedExternalPluginId } = useAuthParameters();
  const pluginId = params.get(PLUGIN_ID_PARAM);
  const handleAuthentication = async () => {
    setRequestedExternalPluginId(pluginId);

    const redirectUri = urlJoin(
      window.location.origin,
      getAppMountUriForRedirect(),
      loginCallbackPath,
    );
    const response = await requestLoginByExternalPlugin!(pluginId!, {
      redirectUri,
    });
    const data = JSON.parse(response?.authenticationData || "");

    if (data && !response?.errors?.length) {
      window.location.href = data.authorizationUrl;
    }
  };

  useEffect(() => {
    if (shouldRedirect && !authenticated && !authenticating) {
      handleAuthentication();
    }
  }, [shouldRedirect, authenticated, authenticating]);

  return {
    authenticated,
    authenticating: (authenticating || shouldRedirect) && !isCredentialsLogin, // Prevent redirecting when user is logging in with credentials
  };
};
