import { type UserContextError } from "@dashboard/auth/types";
import { defineMessages, type IntlShape } from "react-intl";

export const loginPageMessages = defineMessages({
  loadingLoginMethods: {
    id: "tZ+8E3",
    defaultMessage: "Loading login methods",
    description: "spinner aria label on login page",
  },
  passwordLoginDisabled: {
    id: "BtsJ+e",
    defaultMessage:
      "Password login is disabled. Contact your administrator to configure an external authentication method or enable password login.",
    description: "empty state message when no login method is available",
  },
});

const errorMessages = defineMessages({
  loginError: {
    id: "FopBSj",
    defaultMessage: "Your username and/or password are incorrect. Please try again.",
    description: "error message",
  },
  unknownLoginError: {
    id: "Wr5UOV",
    defaultMessage: "Login went wrong. Please try again.",
    description: "error message",
  },
  serverError: {
    id: "ChGI4V",
    defaultMessage: "Saleor is unavailable, please check your network connection and try again.",
    description: "error message",
  },
  noPermissionsError: {
    id: "7Jg9ec",
    defaultMessage: "You don't have permission to login.",
    description: "error message",
  },
  loginAttemptDelay: {
    defaultMessage: "Please wait a moment before trying again.",
    description: "error message",
    id: "RyZd9J",
  },
});

export function getErrorMessage(err: UserContextError, intl: IntlShape): string {
  switch (err) {
    case "loginError":
      return intl.formatMessage(errorMessages.loginError);
    case "externalLoginError":
      return intl.formatMessage(errorMessages.unknownLoginError);
    case "unknownLoginError":
      return intl.formatMessage(errorMessages.unknownLoginError);
    case "serverError":
      return intl.formatMessage(errorMessages.serverError);
    case "noPermissionsError":
      return intl.formatMessage(errorMessages.noPermissionsError);
    case "loginAttemptDelay":
      return intl.formatMessage(errorMessages.loginAttemptDelay);
    case "invalidCredentials":
      return intl.formatMessage(errorMessages.loginError);
    default:
      return intl.formatMessage(errorMessages.unknownLoginError);
  }
}
