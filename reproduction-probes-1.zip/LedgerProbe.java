package com.marketplace.ledger;
import com.marketplace.shared.api.*;
import java.util.*;
import java.time.Instant;
import static org.mockito.Mockito.*;
public class LedgerProbe {
 public static void main(String[] args) {
  UUID owner=UUID.randomUUID(),consumer=UUID.randomUUID();Map<UUID,ProviderBalance> balances=new HashMap<>();
  ProviderBalanceRepository balanceRepo=mock(ProviderBalanceRepository.class);
  when(balanceRepo.findById(any())).thenAnswer(i->Optional.ofNullable(balances.get(i.getArgument(0))));
  when(balanceRepo.save(any())).thenAnswer(i->{ProviderBalance b=i.getArgument(0);balances.put(b.getId(),b);return b;});
  var ledger=new LedgerService(mock(LedgerEntryRepository.class),balanceRepo);
  PaymentIntentLookupPort intents=mock(PaymentIntentLookupPort.class);BookingParticipantProvider bookings=mock(BookingParticipantProvider.class);
  var listener=new LedgerPaymentEventListener(ledger,intents,bookings,0.10);
  for(String currency:List.of("SAR","USD")) {
   UUID payment=UUID.randomUUID(),booking=UUID.randomUUID();
   when(intents.findById(payment)).thenReturn(Optional.of(new PaymentIntentDetails(payment,booking,consumer,"SUCCEEDED")));
   when(bookings.getBookingInfo(booking)).thenReturn(new BookingInfo(owner,consumer,"CONFIRMED",10000L,currency,Instant.now(),Instant.now().plusSeconds(3600)));
   listener.onPaymentCompleted(new PaymentStateChangedEvent(payment,"COMPLETED"));
  }
  long total=ledger.getBalance(owner).availableCents();
  if(total!=18000 || balances.size()!=1)throw new AssertionError("Expected mixed monetary units in one balance");
  System.out.println("REPRODUCED R9: 100 SAR + 100 USD minus 10% each became one untyped 18000 balance; currencies discarded");
 }
}
