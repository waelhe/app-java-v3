package com.marketplace.identity;
import java.time.Instant;
import java.util.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.oauth2.core.*;
import org.springframework.security.oauth2.server.authorization.*;
import org.springframework.security.oauth2.server.authorization.client.*;
import org.springframework.security.oauth2.server.authorization.settings.*;
import org.springframework.security.oauth2.server.authorization.authentication.*;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import com.marketplace.shared.security.SubjectPseudonymizer;
import static org.mockito.Mockito.*;
public class SessionProbe {
 public static void main(String[] args) {
  String username="review@example.invalid";
  UserDetails login=org.springframework.security.core.userdetails.User.withUsername(username).password("unused").roles("CONSUMER").build();
  Authentication session=UsernamePasswordAuthenticationToken.authenticated(login,null,login.getAuthorities());
  User entity=User.create(username,username,"Synthetic",UserRole.CONSUMER);
  UserRepository users=mock(UserRepository.class);when(users.findById(entity.getId())).thenReturn(Optional.of(entity));
  UserDetailsManager loginStore=mock(UserDetailsManager.class);when(loginStore.loadUserByUsername(username)).thenReturn(login);
  UserService service=new UserService(users,mock(ApplicationEventPublisher.class),loginStore,mock(JdbcTemplate.class),mock(SubjectPseudonymizer.class),mock(AuthoredContentPurgeService.class),mock(AuditHistoryPurgeService.class),null);
  service.updateUserStatus(entity.getId(),"DISABLED","review","admin");
  verify(loginStore).updateUser(argThat(u->!u.isEnabled()));
  String redirect="https://synthetic.invalid/callback";
  RegisteredClient client=RegisteredClient.withId("synthetic").clientId("synthetic").clientSecret("unused").clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC).authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE).redirectUri(redirect).scope("read").clientSettings(ClientSettings.builder().requireAuthorizationConsent(false).build()).build();
  RegisteredClientRepository clients=mock(RegisteredClientRepository.class);when(clients.findByClientId("synthetic")).thenReturn(client);
  OAuth2AuthorizationService authorizations=mock(OAuth2AuthorizationService.class);
  var provider=new OAuth2AuthorizationCodeRequestAuthenticationProvider(clients,authorizations,mock(OAuth2AuthorizationConsentService.class));
  provider.setAuthorizationCodeGenerator(ctx->new OAuth2AuthorizationCode("synthetic-code",Instant.now(),Instant.now().plusSeconds(60)));
  var req=new OAuth2AuthorizationCodeRequestAuthenticationToken("https://auth.invalid/oauth2/authorize","synthetic",session,redirect,"state",Set.of("read"),Map.of("code_challenge","abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ","code_challenge_method","S256"));
  org.springframework.security.oauth2.server.authorization.context.AuthorizationServerContextHolder.setContext(new org.springframework.security.oauth2.server.authorization.context.AuthorizationServerContext() {
   public String getIssuer(){return "https://auth.invalid";}
   public AuthorizationServerSettings getAuthorizationServerSettings(){return AuthorizationServerSettings.builder().issuer(getIssuer()).build();}
  });
  var result=(OAuth2AuthorizationCodeRequestAuthenticationToken)provider.authenticate(req);
  if(result.getAuthorizationCode()==null)throw new AssertionError("Expected code from retained session");
  verify(authorizations).save(any());
  System.out.println("REPRODUCED R8: actual account disable followed by SAS 7.1.1 issues new authorization code from retained session");
 }
}
