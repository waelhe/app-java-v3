package com.marketplace.payments;
import java.util.*;
import org.springframework.context.ApplicationEventPublisher;
import com.marketplace.shared.api.BookingParticipantProvider;
import com.marketplace.shared.security.CurrentUserProvider;
import static org.mockito.Mockito.*;
public class WebhookProbe {
 public static void main(String[] args) {
  UUID intentId=UUID.randomUUID();
  PaymentIntent intent=new PaymentIntent(intentId,UUID.randomUUID(),UUID.randomUUID(),1000L,"synthetic");intent.markProcessing();
  PaymentIntentRepository intents=mock(PaymentIntentRepository.class);when(intents.findById(intentId)).thenReturn(Optional.of(intent));
  PaymentWebhookEventRepository events=mock(PaymentWebhookEventRepository.class);
  // Durable state reachable if the worker stops after REQUIRES_NEW record commit,
  // before payment settlement starts. No successful transition has happened.
  when(events.findByProviderAndEventId("stripe","evt_review")).thenReturn(Optional.of(PaymentWebhookEvent.create("stripe","evt_review","payment_intent.succeeded")));
  PaymentIntentSettlementService settlement=mock(PaymentIntentSettlementService.class);
  var service=new PaymentsService(intents,mock(PaymentRepository.class),events,mock(ApplicationEventPublisher.class),mock(CurrentUserProvider.class),mock(BookingParticipantProvider.class),mock(PaymentWebhookSecurity.class),new WebhookEventRecorder(events),settlement,null);
  boolean processed=service.handleVerifiedWebhook("stripe","evt_review","payment_intent.succeeded",intentId,"pi_review");
  if(processed || intent.getStatus()!=PaymentIntentStatus.PROCESSING)throw new AssertionError("Expected lost processing");
  verifyNoInteractions(settlement);
  System.out.println("REPRODUCED R10: redelivery from simulated post-record crash state is acknowledged without settlement");
 }
}
