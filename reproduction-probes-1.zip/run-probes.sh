#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo 'Usage: bash run-probes.sh /absolute/path/to/app-java-v3' >&2
  exit 2
fi
probe_repo=$(cd "$1" && pwd)
probe_dir=$(cd "$(dirname "$0")" && pwd)
probe_build=$(mktemp -d /tmp/app-java-review-probes.XXXXXX)
trap 'rm -rf "$probe_build"' EXIT
python3 - "$probe_repo" "$probe_build/classpath" <<'PY'
import sys
from pathlib import Path
import xml.etree.ElementTree as ET
repo=Path(sys.argv[1])
report=repo/'marketplace-app/target/surefire-reports/TEST-com.marketplace.MarketplaceApplicationTest.xml'
props={p.get('name'):p.get('value') for p in ET.parse(report).getroot().findall('./properties/property')}
cp=props['java.class.path']
missing=[p for p in cp.split(':') if not Path(p).exists()]
if missing:
    raise SystemExit('Classpath from Maven report contains missing paths; build tests in this checkout first.')
Path(sys.argv[2]).write_text(cp)
PY
probe_cp=$(cat "$probe_build/classpath")
javac -cp "$probe_cp" -d "$probe_build/classes" "$probe_dir/ReviewProbes.java" "$probe_dir/MediaProbe.java" "$probe_dir/SessionProbe.java" "$probe_dir/LedgerProbe.java" "$probe_dir/WebhookProbe.java"
for probe_class in com.marketplace.payments.ReviewProbes com.marketplace.identity.SessionProbe com.marketplace.ledger.LedgerProbe com.marketplace.payments.WebhookProbe; do
  java -cp "$probe_build/classes:$probe_cp" "$probe_class"
done
