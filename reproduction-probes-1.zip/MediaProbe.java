package com.marketplace.media;
import com.marketplace.shared.api.*;
import com.marketplace.shared.security.CurrentUserProvider;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.beans.factory.ObjectProvider;
import java.util.*;
import static org.mockito.Mockito.*;
public class MediaProbe {
static UUID id(){return UUID.randomUUID();}
static void check(boolean c,String m){if(!c)throw new AssertionError(m);}
@SuppressWarnings("unchecked") static <T> ObjectProvider<T> provider(T v){ObjectProvider<T> p=mock(ObjectProvider.class);when(p.getIfAvailable()).thenReturn(v);return p;}
 public static void mediaHasNoListingVisibilityGate() {
  MediaAssetRepository repo=mock(MediaAssetRepository.class);S3MediaStorage storage=mock(S3MediaStorage.class);ListingPriceProvider listings=mock(ListingPriceProvider.class);
  UUID listing=id();MediaAsset asset=MediaAsset.create(listing,id(),"synthetic.jpg","image/jpeg",100L,1);asset.markUploaded();
  when(repo.findByListingIdAndStatusOrderByPositionAsc(listing,MediaAssetStatus.UPLOADED)).thenReturn(List.of(asset));when(storage.presignDownload(anyString())).thenReturn("https://synthetic.invalid/image");
  MediaService service=new MediaService(repo,provider(storage),null,listings,mock(ProviderLookupPort.class),mock(CurrentUserProvider.class),mock(ApplicationEventPublisher.class),null);
  check(service.listByListing(listing).size()==1,"Expected signed media response");verifyNoInteractions(listings);
  System.out.println("REPRODUCED R5: media URLs issued without any listing visibility lookup");
 }
}
