package com.marketplace.payments;
import com.marketplace.availability.*;
import com.marketplace.booking.*;
import com.marketplace.payments.*;
import com.marketplace.search.*;
import com.marketplace.media.*;
import com.marketplace.shared.api.*;
import com.marketplace.shared.security.CurrentUserProvider;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.PageRequest;
import org.springframework.modulith.moments.DayHasPassed;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;
import static org.mockito.Mockito.*;

public class ReviewProbes {
 static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
 static UUID id() { return UUID.randomUUID(); }
 @SuppressWarnings("unchecked") static <T> ObjectProvider<T> provider(T value) {
  ObjectProvider<T> p = mock(ObjectProvider.class); when(p.getIfAvailable()).thenReturn(value); return p;
 }
 static class Slots {
  UUID owner=id(); Instant start=Instant.parse("2026-10-05T09:00:00Z"), end=start.plusSeconds(3600);
  List<AvailabilitySlot> rows=new ArrayList<>();
  AvailabilitySlotRepository repo=mock(AvailabilitySlotRepository.class);
  ProviderAvailabilityRuleRepository rules=mock(ProviderAvailabilityRuleRepository.class);
  AvailabilityService service=new AvailabilityService(repo,rules,mock(ProviderTimeOffRepository.class),mock(ApplicationEventPublisher.class));
  Slots() {
   rows.add(AvailabilitySlot.open(owner,start,end));
   when(repo.findFirstByProviderIdAndStartsAtAndEndsAtAndBookedFalse(any(),any(),any())).thenAnswer(i -> rows.stream().filter(s -> !s.isBooked() && s.getProviderId().equals(i.getArgument(0)) && s.getStartsAt().equals(i.getArgument(1)) && s.getEndsAt().equals(i.getArgument(2))).findFirst());
   when(repo.findFirstByProviderIdAndStartsAtAndEndsAtAndBookedTrue(any(),any(),any())).thenAnswer(i -> rows.stream().filter(s -> s.isBooked() && s.getProviderId().equals(i.getArgument(0)) && s.getStartsAt().equals(i.getArgument(1)) && s.getEndsAt().equals(i.getArgument(2))).findFirst());
   when(repo.save(any())).thenAnswer(i -> {AvailabilitySlot s=i.getArgument(0);rows.add(s);return s;});
  }
 }
 static void cancellationReleasesOtherBooking() {
  Slots s=new Slots(); BookingRepository repo=mock(BookingRepository.class);
  Booking a=Booking.create(id(),s.owner,id(),1000L,"SAR",s.start,s.end,null);
  Booking b=Booking.create(id(),s.owner,id(),1000L,"SAR",s.start,s.end,null);
  when(repo.findById(a.getId())).thenReturn(Optional.of(a));when(repo.findById(b.getId())).thenReturn(Optional.of(b));
  BookingService service=new BookingService(repo,mock(CurrentUserProvider.class),mock(ApplicationEventPublisher.class),mock(ListingPriceProvider.class),s.service,mock(EffectivePricePort.class));
  service.autoConfirm(a.getId()); check(s.rows.getFirst().isBooked(),"A must reserve slot");
  service.autoCancel(b.getId());
  check(a.getStatus()==BookingStatus.CONFIRMED && !s.rows.getFirst().isBooked(),"Expected confirmed A with freed slot");
  System.out.println("REPRODUCED R2: cancelling pending B frees confirmed A's slot");
 }
 static void generationDuplicatesBookedSlot() {
  Slots s=new Slots();s.service.bookSlot(s.owner,s.start,s.end);
  when(s.rules.findByDayOfWeek(DayOfWeek.MONDAY)).thenReturn(List.of(ProviderAvailabilityRule.create(s.owner,DayOfWeek.MONDAY,LocalTime.of(9,0),LocalTime.of(10,0))));
  s.service.onDayHasPassed(DayHasPassed.of(LocalDate.of(2026,10,5)));
  check(s.rows.size()==2 && s.service.hasExactAvailableSlot(s.owner,s.start,s.end),"Expected duplicate open slot");
  System.out.println("REPRODUCED R3: daily generation adds open duplicate of booked slot");
 }
 static class Payments {
  PaymentIntentRepository intents=mock(PaymentIntentRepository.class);PaymentRepository payments=mock(PaymentRepository.class);
  PspChannel channel=mock(PspChannel.class);BookingParticipantProvider bookings=mock(BookingParticipantProvider.class);
  ApplicationEventPublisher events=mock(ApplicationEventPublisher.class);
  PaymentsService service=new PaymentsService(intents,payments,mock(PaymentWebhookEventRepository.class),events,mock(CurrentUserProvider.class),bookings,mock(PaymentWebhookSecurity.class),mock(WebhookEventRecorder.class),new PaymentIntentSettlementService(intents,payments,events),provider(channel));
 }
 static void automaticRefundDoesNotReachProvider() {
  Payments p=new Payments();UUID booking=id();PaymentIntent intent=PaymentIntent.create(booking,id(),1000L,"SAR","r1");intent.markProcessing();intent.assignPspIntentId("pi_synthetic_review");intent.markSucceeded();
  Payment payment=Payment.create(intent.getId(),1000L);payment.markCompleted("synthetic");
  when(p.intents.findByBookingId(booking)).thenReturn(Optional.of(intent));when(p.payments.findByPaymentIntentId(intent.getId())).thenReturn(Optional.of(payment));
  p.service.autoRefundByBooking(booking);
  check(intent.getStatus()==PaymentIntentStatus.REFUNDED && payment.getStatus()==PaymentStatus.REFUNDED,"Expected local refund");verifyNoInteractions(p.channel);
  System.out.println("REPRODUCED R1: linked PSP payment marked REFUNDED with zero PSP calls");
 }
 static void repeatedBookingIntents() {
  Payments p=new Payments();UUID booking=id(), consumer=id();
  when(p.bookings.getBookingInfo(booking)).thenReturn(new BookingInfo(id(),consumer,"CONFIRMED",1000L,"SAR",Instant.now(),Instant.now().plusSeconds(3600)));
  when(p.intents.save(any())).thenAnswer(i->i.getArgument(0));
  PaymentIntent a=p.service.createIntent(booking,consumer,"one"),b=p.service.createIntent(booking,consumer,"two");
  check(!a.getId().equals(b.getId()) && a.getBookingId().equals(b.getBookingId()),"Expected two intents");
  System.out.println("REPRODUCED R4: same booking accepts two independent payable intents");
 }
 static void fullTextDropsFilters() {
  CatalogSearchPort catalog=mock(CatalogSearchPort.class); SearchService service=new SearchService(catalog,mock(AvailabilityLookupPort.class),mock(GeoLookupPort.class),mock(RealestatePropertyFilterPort.class));
  var expensive=new ListingSummary(id(),"villa","other",new BigDecimal("9999"),"SAR","owner");
  when(catalog.searchFullText(eq("villa"),any())).thenReturn(new PagedResponse<>(List.of(expensive),0,20,1,1,true));
  var result=service.search(new SearchCriteria("villa","stay",null,new BigDecimal("100"),null,null,8),PageRequest.of(0,20));
  check(result.getContent().getFirst().price().compareTo(new BigDecimal("100"))>0,"Expected out-of-filter result");
  verify(catalog).searchFullText(eq("villa"),any());verifyNoMoreInteractions(catalog);
  System.out.println("REPRODUCED R6: text search returns wrong category/price; criteria never reach catalog");
 }
 static void webSocketRejectsNormalSubject() {
  var repo=mock(com.marketplace.messaging.ConversationRepository.class);
  var manager=new com.marketplace.messaging.ConversationSubscriptionAuthorizationManager(repo);
  UUID conversation=id();
  var jwt=org.springframework.security.oauth2.jwt.Jwt.withTokenValue("synthetic").header("alg","RS256").subject("review@example.invalid").build();
  var auth=new org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken(jwt,List.of(new org.springframework.security.core.authority.SimpleGrantedAuthority("ROLE_CONSUMER")));
  var message=org.springframework.messaging.support.MessageBuilder.withPayload("subscribe").build();
  var context=new org.springframework.security.messaging.access.intercept.MessageAuthorizationContext<>(message,Map.of("conversationId",conversation.toString()));
  check(!manager.authorize(()->auth,context).isGranted(),"Expected email subject rejected");verifyNoInteractions(repo);
  System.out.println("REPRODUCED R7: valid email subject denied STOMP subscription before ownership lookup");
 }
 public static void main(String[] args) {
  automaticRefundDoesNotReachProvider(); cancellationReleasesOtherBooking();generationDuplicatesBookedSlot();repeatedBookingIntents();fullTextDropsFilters();com.marketplace.media.MediaProbe.mediaHasNoListingVisibilityGate();webSocketRejectsNormalSubject();
  System.out.println("7/7 review probes reproduced the reported behavior; repository source unchanged.");
 }
}
