# فحوص إعادة إنتاج نتائج المراجعة

النسخة المطلوبة: `73da7395bb45fde40f902da6f0eb1462a5cd9af1` من `waelhe/app-java-v3`.

تتضمن الحزمة خمسة ملفات Java تثبت عشرة عيوب. تستخدم أصناف الإنتاج الفعلية مع Mockito عند حدود المستودعات والخدمات الخارجية. نجاح التنفيذ يعني إثبات السلوك المعيب القائم، وليس نجاح إصلاحه.

## التشغيل

1. جهّز Java 25 وبيئة الاختبار بحسب تعليمات المستودع.
2. ابنِ المستودع بأمر `./mvnw clean verify --batch-mode` أو استعمل نتائج البناء الحالية لنفس النسخة. يجب وجود تقرير Surefire لاختبار `MarketplaceApplicationTest`؛ تُستخرج منه قائمة اعتماديات Maven الفعلية.
3. فك الحزمة في مجلد خارج المستودع.
4. نفّذ `bash run-probes.sh /absolute/path/to/app-java-v3`. يجب أن تكون `java` و`javac` للإصدار 25 على PATH. في بيئة المراجعة: `mise exec java@25 -- bash run-probes.sh /absolute/path/to/app-java-v3`.

لا يحتاج تشغيل الفحوص المعزولة إلى Stripe/S3 أو قاعدة بيانات. البيئة الخارجية لازمة فقط لتشغيل بوابة Maven الشاملة التي تسبقها. تنشئ الفحوص كائنات وبيانات اصطناعية في الذاكرة.

## المطابقة

| الفحص | النتيجة |
|---|---|
| ReviewProbes.automaticRefundDoesNotReachProvider | R1: استرداد محلي دون PSP |
| ReviewProbes.cancellationReleasesOtherBooking | R2: تحرير فترة حجز آخر |
| ReviewProbes.generationDuplicatesBookedSlot | R3: تكرار فترة محجوزة |
| ReviewProbes.repeatedBookingIntents | R4: نيتان للحجز نفسه |
| MediaProbe.mediaHasNoListingVisibilityGate | R5: غياب فحص ظهور الإعلان |
| ReviewProbes.fullTextDropsFilters | R6: إسقاط مرشحات النص |
| ReviewProbes.webSocketRejectsNormalSubject | R7: رفض subject المستخدم العادي |
| SessionProbe | R8: إصدار تفويض من جلسة بعد تعطيل الحساب |
| LedgerProbe | R9: جمع العملات في رصيد واحد |
| WebhookProbe | R10: فقد المعالجة بعد بقاء سجل منع التكرار |

`results.txt` يتضمن علامات إعادة الإنتاج المرصودة. التفاصيل والأولوية والإصلاح المقترح في التقرير العربي.
